package com.yash.pms.service;

import java.io.Console;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.yash.pms.exception.CompanyNotFoundException;
import com.yash.pms.exception.EmailValidationException;
import com.yash.pms.model.Company;
import com.yash.pms.utility.CompanyUtilities;

public class CompanyServiceImplement extends CompanyUtilities implements CompanyService {

	@Override
	public void addCompany() throws EmailValidationException{
		// TODO Auto-generated method stub
		System.out.println("**********WELCOME************");
		System.out.println("Enter the Company id");
		int compnayId = sc.nextInt();

		System.out.println("Enter the Company Name:");
		String company_Name = sc1.nextLine();

		System.out.println("Enter the Company Contact Number:");
		long contact_Number = sc.nextLong();

		System.out.println("Enter the Company Address:- ");
		String address = sc1.nextLine();

		System.out.println("Enter the number of employees in company:- ");
		int no_Of_Employees = sc.nextInt();

		String regex = "^[A-Za-z0-9+_.-]+@(.+)$"; 
		Pattern pattern = Pattern.compile(regex);  
		System.out.println("Enter the Company email address:- ");
		String email_Address = sc1.nextLine();
		Matcher matcher = pattern.matcher(email_Address);  
        //System.out.print(email_Address +" this email address is wrong: "+ matcher.matches()+"\n"); 

		 /* com.setId(compnayId); 
		  com.setCompany_Name(company_Name);
		  com.setContact_Number(contact_Number); 
		  com.setAddress(address);
		  com.setNo_Of_Employees(no_Of_Employees);
		  com.setEmail_Address(email_Address);*/
		  
		 
		// c.add(com);
		 
		if(matcher.matches()) {
	c.add(new Company(compnayId, company_Name, contact_Number, address, no_Of_Employees, email_Address));
		

		}
		else {
			throw new EmailValidationException("Check email address is wrong can you please  enter valid email address");
		}
	}

	@Override
	public void displayCompany() {
		Iterator<Company> i = c.iterator();
		while (i.hasNext()) {
			Company p = i.next();
			System.out.println(p);
		}

	}

	@Override
	public void searchCompany(int companyId) throws CompanyNotFoundException {
		// TODO Auto-generated method stub
		boolean found = false;
		System.out.print("Enter the Comapny id:");
		companyId = sc.nextInt();
		System.out.println("line 59 " + companyId);
		Iterator<Company> companyIterator = c.iterator();
		while (companyIterator.hasNext()) {
			com = companyIterator.next();
			if (com.getId()==companyId) {
				System.out.println(com + "    " + com.getId());
				found = true;
			}
		}
		if (!found) {
			throw new CompanyNotFoundException(
	                "Could not find Company name " + companyId);
		}

		System.out.println("*******************");

	}

	
	@Override
	public void updateCompany(String name) {
		boolean found = false;
		System.out.println("please enter the name");
		name = sc.next();
		Iterator<Company> li = c.iterator();
		while (li.hasNext()) {
			com = li.next();
			Company c = new Company();
			if (com.getCompany_Name().equalsIgnoreCase(name)) {
				System.out.println("Enter the Company Number:");
				long contact_Number = sc.nextLong();

				System.out.println("Enter the Company Address:- ");
				String address = sc1.nextLine();

				System.out.println("Enter the number of employees in company:- ");
				int no_Of_Employees = sc.nextInt();

				System.out.println("Enter the Company id");
				int compnayId = sc.nextInt();

				System.out.println("Enter the Company Name:");
				String company_Name = sc1.nextLine();

				System.out.println("Enter the Company email address:- ");
				String email_Address = sc1.nextLine();

				// li.set(new Product(id,productName,productPrice,productQunty));
				com.setContact_Number(contact_Number);
				com.getContact_Number();
				com.setAddress(address);
				com.setNo_Of_Employees(no_Of_Employees);
				com.setId(compnayId);
				com.setEmail_Address(email_Address);
				com.setCompany_Name(company_Name);

				found = true;

			}
		}
		if (!found) {
			System.out.println("Company not found");
		} else {
			System.out.println("Company is updated successfully");
		}

	}

	@Override
	public void deleteCompany(int id) {
		boolean found = false;
		System.out.println("Enter the company Id which you want delete");
		id = sc.nextInt();
		Iterator<Company> i = c.iterator();
		while (i.hasNext()) {
			com = i.next();
			if (com.getId() == id) {
				i.remove();
				found = true;
			}
		}
		if (!found) {
			System.out.println("Company not found");

		} else {
			System.out.println("Company is deleted successfully...!");
		}

		System.out.println("******************************");

	}

}
