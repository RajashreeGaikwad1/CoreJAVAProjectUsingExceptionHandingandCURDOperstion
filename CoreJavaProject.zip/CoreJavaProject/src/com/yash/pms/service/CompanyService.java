package com.yash.pms.service;

import com.yash.pms.exception.CompanyNotFoundException;
import com.yash.pms.exception.EmailValidationException;

public interface CompanyService {
	public void addCompany() throws EmailValidationException;
	public void displayCompany();
	public void searchCompany(int companyId) throws CompanyNotFoundException;
	public void updateCompany(String name);
	public void deleteCompany(int id);
}
