package com.yash.pms.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.pms.exception.CompanyNotFoundException;
import com.yash.pms.model.Company;
import com.yash.pms.service.CompanyServiceImplement;

public class CompanyUtilities {
	protected Company com=new Company();
    protected List<Company> c = new ArrayList<Company>();
   protected static Scanner sc = new Scanner(System.in);
    protected Scanner sc1 = new Scanner(System.in);
   
    
   
    protected static CompanyServiceImplement companyImplement=new CompanyServiceImplement();
    
    
}
