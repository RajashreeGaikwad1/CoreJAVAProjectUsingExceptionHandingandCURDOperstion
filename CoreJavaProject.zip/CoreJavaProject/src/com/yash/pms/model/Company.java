package com.yash.pms.model;

public class Company {
	private int id;
	private String company_Name;
	private long contact_Number;
	private String address;
	private int no_Of_Employees;
	private String email_Address;
	
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Company(int id, String company_Name, long contact_Number, String address, int no_Of_Employees,
			String email_Address) {
		super();
		this.id = id;
		this.company_Name = company_Name;
		this.contact_Number = contact_Number;
		this.address = address;
		this.no_Of_Employees = no_Of_Employees;
		this.email_Address = email_Address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompany_Name() {
		return company_Name;
	}

	public void setCompany_Name(String company_Name) {
		this.company_Name = company_Name;
	}

	public long getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(long contact_Number) {
		this.contact_Number = contact_Number;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getNo_Of_Employees() {
		return no_Of_Employees;
	}

	public void setNo_Of_Employees(int no_Of_Employees) {
		this.no_Of_Employees = no_Of_Employees;
	}

	public String getEmail_Address() {
		return email_Address;
	}

	public void setEmail_Address(String email_Address) {
		this.email_Address = email_Address;
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", company_Name=" + company_Name + ", contact_Number=" + contact_Number
				+ ", address=" + address + ", no_Of_Employees=" + no_Of_Employees + ", email_Address=" + email_Address
				+ "]";
	}
	

	
}
