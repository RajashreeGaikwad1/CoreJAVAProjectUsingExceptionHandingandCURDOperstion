package com.yash.pms.main;

import java.util.Scanner;

import com.yash.pms.exception.CompanyNotFoundException;
import com.yash.pms.exception.EmailValidationException;
import com.yash.pms.utility.CompanyUtilities;

public class TestCompany extends CompanyUtilities {

	public static void main(String[] args) throws CompanyNotFoundException, EmailValidationException {
		// TODO Auto-generated method stub
		String userinput;
		int exit = 0;
		
		
		while (exit == 0){ 
		
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.Search");
			System.out.println("4.Update");
			System.out.println("5.Delete");
			System.out.println("6.Terminate");
			System.out.println("Enter your choice");
		
		userinput = sc.next();
			switch (userinput) {

			case "Add":
				companyImplement.addCompany();
				break;

			case "Display":

				companyImplement.displayCompany();

				break;

			case "Search":
				int companyId = 0;
				companyImplement.searchCompany(companyId);
				break;

			case "Update":
				String name1 = "";
				companyImplement.updateCompany(name1);
				break;

			case "Delete":
				int id = 0;
				companyImplement.deleteCompany(id);
				break;
				
			case "Terminate":
				System.out.println("Terminated!!");
				System.exit(0);
				break;

			default:
				break;

			}

			
		}

	}
	
	/*public static String welcomeMenu(Scanner sc) {
		System.out.println("\n\n***********welcome to Company  Management Project***************");
		System.out.println("************select any one of the following options*************");
		System.out.println("1.Add");
		System.out.println("2.Display");
		System.out.println("3.Search");
		System.out.println("4.Update");
		System.out.println("5.Delete");
		System.out.println("6.exit");
		System.out.println("Enter your choice");

		
		String userinput = sc.next();
		return userinput;
	}*/

}
