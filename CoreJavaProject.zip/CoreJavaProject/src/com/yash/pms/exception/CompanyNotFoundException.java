package com.yash.pms.exception;

public class CompanyNotFoundException extends Exception {
 
    public CompanyNotFoundException(String message) {
        super(message);
    }
}